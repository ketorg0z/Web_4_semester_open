function checkWord(word, context) {
    var items = get_items(get_request(context))
    if (items == null) return false;
    var index = items[1].words.indexOf(word)
    if (index == -1) return false;
    return true;
}

function checkRight(word, context) {
    var items = get_items(get_request(context))
    return (items[1].words[items[0].rightId] === word)
}