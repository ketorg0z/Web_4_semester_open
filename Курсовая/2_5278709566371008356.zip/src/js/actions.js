function answer(word, context) {
    addAction({
        type: "answer",
        word: word
    }, context);
}